import pandas as pd

data = pd.read_csv('Data Analysis\MovieRec\movies_metadata.csv')
data

data = data[['original_title', 'overview', 'vote_average', 'vote_count']]
data

nums = [2, 5, 8, 10, 34, 56, 57, 76, 89, 101, 125]
nums = pd.DataFrame(nums)
nums.quantile(0.9)

minVotes = data['vote_count'].quantile(0.9) # top 10%
data = data[data['vote_count'] > minVotes]

meanVoteAvg = data['vote_average'].mean()
minVotes, meanVoteAvg

data

# (count / count + minCount) * voteAvg + (minCount / minCount + count) * meanVoteAvg
def weighScore(movie):

  voteCount, voteAvg = movie['vote_count'], movie['vote_average']

  weightedScore = (voteCount / (voteCount + minVotes)) * voteAvg + (minVotes / (minVotes + voteCount)) * meanVoteAvg
  return weightedScore

data['weightedScore'] = data.apply(weighScore, 1) # column = 0, row = 1 (axis)
data

data = data.sort_values('weightedScore', ascending=False)
data.head(20)

data = pd.read_csv('Data Analysis\MovieRec\movies_metadata.csv')
data['overview'] = data['overview'].fillna('')
data

movieTitles = pd.Series(data.index, index=data['original_title'])
movieTitles

from sklearn.feature_extraction.text import TfidfVectorizer

vectoriser = TfidfVectorizer(stop_words='english')
overviewVectors = vectoriser.fit_transform(data['overview'])

overviewVectors

print('------------------------')

from sklearn.metrics.pairwise import linear_kernel

similarity = linear_kernel(overviewVectors, overviewVectors) # similarity between the current index and all other movies
similarity

def reccomend(movieName):
  index = movieTitles[movieName]
  movie = similarity[index]
  movie = list(enumerate(movie)) # index the movies
  movie = sorted(movie, reverse=True, key=lambda m: m[1]) # sort based on movie similarity
  movie = movie[1:11]
  placeholder = []
  for mov in movie:
    placeholder.append(mov[0])
  movie = placeholder



  return data['original_title'][movie]


print(reccomend('Copycat'))